# CUDA_VISIBLE_DEVICES=0,1 swift sft \
#     --model '../pretrain/GLM-4-9B-0414' \
#     --train_type lora \
#     --dataset ./20250416_ccl_llm_sft_data.jsonl \
#     --dataloader_num_workers 16 \
#     --split_dataset_ratio 0.0 \
#     --seed 2025 \
#     --num_train_epochs 5 \
#     --per_device_train_batch_size 2 \
#     --gradient_accumulation_steps 2 \
#     --per_device_eval_batch_size 1 \
#     --lr_scheduler_type cosine \
#     --warmup_ratio 0.05 \
#     --learning_rate 1e-4 \
#     --max_length 1024 \
#     --target_modules all-linear \
#     --lora_rank 16 \
#     --lora_alpha 32 \
#     --lora_dropout 0.1 \
#     --weight_decay 0.1 \
#     --eval_steps 100 \
#     --save_steps 100 \
#     --save_total_limit 5 \
#     --output_dir ./glm_4_9b_0414 \
#     --logging_steps 5

#推理
CUDA_VISIBLE_DEVICES=0 \
   swift infer \
   --adapters './glm_4_9b_0414/生成的模型名/最大的checkpoint' \
   --max_batch_size 1 \
   --infer_backend pt \
   --max_length 1000 \
   --num_beams 3 \
   --dataset_shuffle false \
   --split_dataset_ratio 1.0 \
   --dataset ./test_data.jsonl \
   --seed 2025 \
   --result_path ./predict_result.jsonl