#训练
CUDA_VISIBLE_DEVICES=0 swift sft \
--model '../pretrain/GLM-4-9B-0414' \
--train_type lora \
--dataset ./sft_data.jsonl \
--dataloader_num_workers 8 \
--split_dataset_ratio 0.0 \
--seed 2025 \
--num_train_epochs 3 \
--per_device_train_batch_size 1 \
--gradient_accumulation_steps 8 \
--per_device_eval_batch_size 1 \
--lr_scheduler_type cosine \
--warmup_ratio 0.05 \
--learning_rate 5e-5 \
--max_length 1024 \
--target_modules all-linear \
--lora_rank 64 \
--lora_alpha 128 \
--lora_dropout 0.1 \
--weight_decay 0.1 \
--eval_steps 100 \
--save_steps 100 \
--save_total_limit 5 \
--output_dir ./glm_4_9b_0414 \
--logging_steps 5

# 推理
# CUDA_VISIBLE_DEVICES=0 \
#     swift infer \
#     --adapters './glm_4_9b_0414/v1-20250507-191422/checkpoint-2985' \
#     --max_batch_size 1 \
#     --infer_backend pt \
#     --max_length 1000 \
#     --num_beams 3 \
#     --dataset_shuffle false \
#     --split_dataset_ratio 1.0 \
#     --dataset ./test_data.jsonl \
#     --seed 2025 \
#     --result_path ./9b_predict_result1.jsonl