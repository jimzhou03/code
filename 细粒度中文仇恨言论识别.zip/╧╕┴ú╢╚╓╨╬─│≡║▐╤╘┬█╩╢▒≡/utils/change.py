# -*- coding: utf-8 -*-
import json

train_file = open('./sft_data.jsonl', 'w', encoding='utf-8')

train_data = json.load(open('./train.json', 'r', encoding='utf-8'))

print(len(train_data))



sys = """
本次任务为细粒度片段级中文仇恨言论识别，基于给定的文本，任务的输入为社交媒体文本，输出为仇恨四元组，顺序依次为评论对象（Target）、论点（Argument）、目标群体（Targeted Group）、是否仇恨（Hateful）。具体说明如下：

评论对象（Target）：帖子的评述对象，如一个人或一个群体。当实例无具体目标时设为NULL。

论点（Argument）：包含对评论目标关键论点的信息片段。

目标群体（Targeted Group）：指包含仇恨信息的评论对象-论点对涉及的目标群体。标注的目标群体包括“地域（Region）”、“种族（种族主义）”、“性别（Sexism）”、“LGBTQ”、“其他（others）”共5类。如样例1中包含了对LGBTQ群体和艾滋病群体的仇恨信息。

是否仇恨（Hateful）：评论对象-论点对是否构成了对某些群体的仇恨言论。

对于非仇恨文本和不包含特定群体的一般攻击性言论，同样需要对目标群体和观点进行抽取，并设为Non-hate。由于样本中可能有多个评论对象，因此可以包含多个四元组。 每个四元组中各个元素之间用" | "分割，并利用 [END] 结尾；如果一条样本中包含多个四元组，不同四元组之间利用 [SEP] 分割。请严格按照顺序和格式提交，不要省略空格。
"""

for item in train_data:
    text = item['content']
    label = item['output']
    temp = {}
    temp["messages"] = [{"role": "system", "content": sys}, {"role": "user", "content": text}, {"role": "assistant", "content": label}]
    json_line = json.dumps(temp, ensure_ascii=False)
    train_file.write(json_line + '\n')


test_file = open('./test_data.jsonl', 'w', encoding='utf-8')

test_data = json.load(open('./test2.json', 'r', encoding='utf-8'))

print(len(test_data))


for item in test_data:
    text = item['content']
    temp = {}
    temp["messages"] = [{"role": "system", "content": sys}, {"role": "user", "content": text}, {"role": "assistant", "content": '无'}]
    json_line = json.dumps(temp, ensure_ascii=False)
    test_file.write(json_line + '\n')