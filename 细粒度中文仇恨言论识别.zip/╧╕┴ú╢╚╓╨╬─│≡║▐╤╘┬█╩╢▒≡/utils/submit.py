# -*- coding: utf-8 -*-
import json
with open('./predict_result.jsonl', 'r', encoding='utf-8') as f:
    preds = f.readlines()

all_preds = []
for line in preds:
    line = json.loads(line)
    response = line['response']
    all_preds.append(response)

# 示例列表

# 打开文件并写入
with open("predict_result.txt", "w", encoding="utf-8") as file:
    for item in all_preds:
        file.write(item + "\n")  # 每个元素后面加换行符S